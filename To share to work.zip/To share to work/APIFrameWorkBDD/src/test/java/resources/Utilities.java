package resources;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Properties;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Utilities {
	static RequestSpecification reqspec; // here we have defined it as static because we have to check the condition
											// that if it is null or not in below method
	// so the single copy will be used for all the instances

	public RequestSpecification requestspecification() throws IOException {
		if (reqspec == null) {
			PrintStream log = new PrintStream(new FileOutputStream("logging.txt"));
			reqspec = new RequestSpecBuilder().setBaseUri(getGlobalValue("baseurl")).setContentType(ContentType.JSON)
					.addQueryParam("key", "qaclick123").addFilter(RequestLoggingFilter.logRequestTo(log))
					.addFilter(ResponseLoggingFilter.logResponseTo(log)).build();
			return reqspec;

		}
		return reqspec; // to add log in same file for multiple test executions

	}

	public String getGlobalValue(String valueRequired) throws IOException {
		String pathOgGlobalPropertyFile = System.getProperty("user.dir")
				+ "\\src\\test\\java\\resources\\GlobalProperties.properties";
		FileInputStream fis = new FileInputStream(pathOgGlobalPropertyFile);
		Properties prop = new Properties();
		prop.load(fis);
		return prop.getProperty(valueRequired);

	}
	
	public String getJsonPathValue(Response response, String key) {	
		String responseAsString = response.asString();
		JsonPath js = new JsonPath(responseAsString);
		return js.get(key).toString();
	}

}
