package stepdefinitions;

import java.io.IOException;

import io.cucumber.java.Before;

public class Hooks {

	@Before("@DeletePlace")
	public void beforeScenario() throws IOException {
		// execute this scode only when place ID is null or prvious code or scenario is
		// not running
		stepDefinition m = new stepDefinition();
		if (stepDefinition.placeid == null) { // jo static variabled hote hai unko class name se call kiya jata hai kar
												// ham object se bhi sakte hai but fir us case me uski koi life nahi
												// hogi
			m.add_Place_Payload_with("shetty", "French", "Asia");
			m.user_calls_using_post_http_request("AddPlaceAPI", "POST");
			m.verifyPlaceIdMapsToName("shetty", "getPlaceAPI");
		}
	}

}
