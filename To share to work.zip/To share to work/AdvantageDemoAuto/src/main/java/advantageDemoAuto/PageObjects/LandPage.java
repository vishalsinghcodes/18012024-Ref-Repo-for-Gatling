package advantageDemoAuto.PageObjects;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.stream.Collectors;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import advantageDemoAuto.AbstractClassReuse.AbstractClass;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LandPage extends AbstractClass {
	public WebDriver driver;
	public LandPage(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, "this");
	}
	

	public void gotoLandingPage() {
		driver.get("https://demo.guru99.com/V1/index.php");
	}
	@FindBy(name="uid")
	WebElement userIdFieldEle;
	
	@FindBy(id="message23")
	WebElement userIdFieldElerequiredMessage;
	
	@FindBy(name="password")
	WebElement passwordFieldEle;
	
	@FindBy(id="message18")
	WebElement passwordFieldElerequiredMessage;
	
	@FindBy(xpath="//a")
	List<WebElement> allWebLinks;
	
	@FindBy(xpath="//img[@alt='Guru99 Demo Sites']")
	WebElement pageIconEle;
	
	@FindBy(xpath="//a[text()='here']")
	WebElement linkToCreateNewCredentialsEle;
	
	@FindBy(name="btnLogin")
	WebElement submitButtonEle;
	
	public void LandPageTitlecheck() {
		waitForElementtoappear(pageIconEle);
		Assert.assertEquals(driver.getTitle(), "GTPL Bank Home Page");		
	}
	
	
	public NewTestUserCreationPage clickOnlinkToCreateNewCredentialsEle() {
		linkToCreateNewCredentialsEle.click();
		NewTestUserCreationPage newTestUserCreationPage = new NewTestUserCreationPage(driver);
		return newTestUserCreationPage;
	}
	
	public ManagerControlPage loginWithIdPw(String un, String pw) {
		userIdFieldEle.sendKeys(un);
		passwordFieldEle.sendKeys(pw);
		submitButtonEle.click();
		ManagerControlPage managerControlPage = new ManagerControlPage(driver);
		return managerControlPage;
		
	}
	
	public boolean checkInvalidUserPopUpAndText(String un, String pw) {
		userIdFieldEle.sendKeys(un);
		passwordFieldEle.sendKeys(pw);
		submitButtonEle.click();
		if(driver.switchTo().alert().getText().contentEquals("User is not valid"))
			{driver.switchTo().alert().accept();
			return true;	
			}
		return false;
	}
	
	public String requiredFieldBlankMessageUserID() {
		Actions a = new Actions(driver);
		a.moveToElement(userIdFieldEle).sendKeys("SomeuserID").doubleClick().sendKeys(Keys.BACK_SPACE).build().perform();;
		return userIdFieldElerequiredMessage.getText();	
	}
	
	public String requiredFieldBlankMessagePassword() {
		Actions a = new Actions(driver);
		a.moveToElement(passwordFieldEle).sendKeys("Someuserpassword").doubleClick().sendKeys(Keys.BACK_SPACE).build().perform();;
		return passwordFieldElerequiredMessage.getText();	
	}
	
}
