package advantageDemoAuto.PageObjects;




import advantageDemoAuto.AbstractClassReuse.AbstractClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NewTestUserCreationPage extends AbstractClass {
	public WebDriver driver;

	public NewTestUserCreationPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, "this");
	}

	@FindBy(xpath="//td//h2")
	WebElement centerTextEle;
	
	@FindBy(name="emailid")
	WebElement emailTextBoxEle;
	
	@FindBy(xpath="//input[@name='btnLogin']")
	WebElement submitButtonEle;
	
	public String getCenterText() {
		return centerTextEle.getText();
	}
	
	public void typeInEmailTextBox(String str) {
		emailTextBoxEle.sendKeys(str);
	}
	
	public NewUserDetailsPage newUserCreationApplication(String emailID) {
		typeInEmailTextBox(emailID);
		submitButtonEle.click();
		NewUserDetailsPage newUserDetailsPage = new NewUserDetailsPage(driver);
		return newUserDetailsPage;
	}

}
