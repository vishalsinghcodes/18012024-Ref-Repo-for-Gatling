package advantageDemoAuto.PageObjects;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.stream.Collectors;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import advantageDemoAuto.AbstractClassReuse.AbstractClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NewUserDetailsPage extends AbstractClass {
	public WebDriver driver;

	public NewUserDetailsPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, "this");
	}

	
	@FindBy(xpath="//tr/td[text()='User ID :']/following-sibling::td")
	WebElement newuserIDEle;
	
	@FindBy(xpath="//tr/td[text()='Password :']/following-sibling::td")
	WebElement newuserPasswordEle;
	
	public String getnewUserID() {
		return newuserIDEle.getText().trim();
	}
	
	public String getnewUserPassword() {
		return newuserPasswordEle.getText().trim();
	}
	
	public void saveNewUserDetailsinPropertyFile(String un, String pw) throws IOException {
		saveNewUserIdAndPassword(un,pw);
	}
	
	
	

}
