package advantageDemoAuto.TestComponents;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryClass implements IRetryAnalyzer {
	int Testcount = 0;
	int max_count = 1;

	@Override
	public boolean retry(ITestResult result) {
		if (Testcount < max_count) {
			Testcount++;
			return true;
		}
		return false;
	}

}
