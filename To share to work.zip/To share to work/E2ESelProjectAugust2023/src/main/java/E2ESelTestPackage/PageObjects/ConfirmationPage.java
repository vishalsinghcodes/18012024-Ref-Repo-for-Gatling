package E2ESelTestPackage.PageObjects;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import abstractComponents.AbstractComponents;

public class ConfirmationPage extends AbstractComponents {
	private WebDriver driver;

	public ConfirmationPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//input[@placeholder='Select Country']")
	WebElement selectCountryAuto;
	
	@FindBy(xpath="//button[@class='ta-item list-group-item ng-star-inserted']/span")
	List<WebElement> countryListEle;
	
	@FindBy(xpath="//a[text()='Place Order ']")
	WebElement placeOrderButton;
	
	
	By countryListEleBy = By.xpath("//button[@class='ta-item list-group-item ng-star-inserted']/span");
	
	public void textInCountryTextBox(String text) {
		Actions a = new Actions(driver);
		a.sendKeys(selectCountryAuto, text).build().perform();	
	}
	
	public void selectCountry(String coun) {
		waitForElementsToBeVisible(countryListEleBy);
		countryListEle.stream().filter(s -> s.getText().equalsIgnoreCase(coun)).collect(Collectors.toList()).get(0)
		.click();
	}
	
	public FinalPage placeOrderButtonPress() {
		placeOrderButton.click();
		FinalPage finalPage = new FinalPage(driver);
		return finalPage;
	}
	
}
