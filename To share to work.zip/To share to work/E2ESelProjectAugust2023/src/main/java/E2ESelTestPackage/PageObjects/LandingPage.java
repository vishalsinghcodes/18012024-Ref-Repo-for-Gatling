package E2ESelTestPackage.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import abstractComponents.AbstractComponents;

public class LandingPage extends AbstractComponents{

	private WebDriver driver;

	public LandingPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	

	//WebElement username = driver.findElement(By.cssSelector("#userEmail"));
	
	@FindBy(css = "#userEmail") // initElements is required 
	WebElement usernameEle; // name of variable
	
	//driver.findElement(By.id("userPassword"))
	@FindBy(id="userPassword")
	WebElement passwordEle;
	
	//driver.findElement(By.id("login"))
	@FindBy(id="login")
	WebElement loginButtonEle;
	
	
	@FindBy(css="div[class*='inserted']:last-of-type")
	WebElement errorToastonLoginPage;
	

	public void goTo() {
		driver.get("https://www.rahulshettyacademy.com/client");
	}
	
	public ProductCataloguePage loginApplication(String un, String pw) { // Application to Login 
		usernameEle.sendKeys(un);
		passwordEle.sendKeys(pw);
		loginButtonEle.click();	
		ProductCataloguePage productCataloguePage = new ProductCataloguePage(driver);
		return productCataloguePage;
	}
	
	public String getErrorMessage() {
		waitForElementToBeVisible(errorToastonLoginPage);
		return errorToastonLoginPage.getText();
	}
	
}
