package eCommerce.PageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ConfirmationPage {
	WebDriver driver;
	
	public ConfirmationPage(WebDriver driver) {
		//super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(css=".hero-primary")
	WebElement headerText;
	
	@FindBy(css=".ng-star-inserted:first-child:first-of-type")
	WebElement orderNumberEle;
	
	public boolean verifyHeaderText(String str) {
		return headerText.getText().equalsIgnoreCase(str);
	}
	
	public String getOrderNumber() {
		return orderNumberEle.getText().split(" ")[1];
	}
	

}
