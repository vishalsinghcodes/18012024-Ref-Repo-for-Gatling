package eCommerce.PageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LandingPage {
	WebDriver driver;
	
	@FindBy(id = "userEmail")
	WebElement emailTextBoxEle;
	
	@FindBy(id="userPassword")
	WebElement passwordTextBoxEle;
	
	@FindBy(id="login")
	WebElement loginButtonEle;
	
	@FindBy(xpath="//div[@role='alert']")
	WebElement wrongLoginToastEle;
	
	public LandingPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void goToLandingPage() {
		driver.get("https://www.rahulshettyacademy.com/client/");
	}
	
	public ProductPage login(String un, String pw) {
		emailTextBoxEle.sendKeys(un);
		passwordTextBoxEle.sendKeys(pw);
		loginButtonEle.click();
		ProductPage productPage = new ProductPage(driver);
		return productPage;
	}
	
	public String getErrorToastMessage() {
		return wrongLoginToastEle.getText();
	}

}
