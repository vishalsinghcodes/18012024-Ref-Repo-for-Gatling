package eCommerce.PageObjects;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import eCommerce.abtractComponent.AbstractClassReusables;

public class PaymentPage extends AbstractClassReusables {
	WebDriver driver;
	
	public PaymentPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[@class='btnn action__submit ng-star-inserted']")
	WebElement placeOrderButton;
	
	@FindBy(xpath="//input[@placeholder='Select Country']")
	WebElement countryTextBoxEle;
	
	@FindBy(xpath="//span[@class='ng-star-inserted']")
	List<WebElement> autoSuggestiveListEle;
	
	public void typeInCountryTextBox(String str) {
		Actions a = new Actions(driver);
		a.sendKeys(countryTextBoxEle,str).build().perform();
	}

	public void SelectCountry(String str) {
		waitForElements(autoSuggestiveListEle);
		autoSuggestiveListEle.stream().filter(s->s.getText().equalsIgnoreCase(str)).collect(Collectors.toList()).get(0).click();
		
	}
	
	public ConfirmationPage clickPlaceOrderButton() {
		placeOrderButton.click();
		ConfirmationPage confirmationPage = new ConfirmationPage(driver);
		return confirmationPage;
	}
	

	}
	
	
	


