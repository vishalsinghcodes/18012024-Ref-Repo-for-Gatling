package eCommerce.PageObjects;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import eCommerce.abtractComponent.AbstractClassReusables;

public class ProductPage extends AbstractClassReusables {
	WebDriver driver;

	public ProductPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='card-body']")
	List<WebElement> proCardsEle;
	
	@FindBy(xpath="//div[@aria-label='Product Added To Cart']")
	WebElement addedToastEle;
	
	@FindBy(css=".ng-tns-c31-0.ng-star-inserted")
	WebElement spinnerAfterOrderEle;

	public void buyProduct(String product) {
		waitForElements(proCardsEle);
		proCardsEle.stream().filter(s -> s.findElement(By.tagName("b")).getText().contains(product)).map(s -> {
			WebElement e = s.findElement(By.xpath("button[2]"));
			return e;
		}).collect(Collectors.toList()).get(0).click();	
		waitForElement(addedToastEle);
		waitForElementToDisappear(spinnerAfterOrderEle);
		
	}
	
	

}
