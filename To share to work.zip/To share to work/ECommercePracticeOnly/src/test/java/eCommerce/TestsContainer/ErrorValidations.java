package eCommerce.TestsContainer;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import eCommerce.PageObjects.CheckOutPage;
import eCommerce.PageObjects.ConfirmationPage;
import eCommerce.PageObjects.OrderHistoryPageEcommerce;
import eCommerce.PageObjects.PaymentPage;
import eCommerce.PageObjects.ProductPage;
import eCommerce.TestComponents.BaseTest;
import eCommerce.TestComponents.RetryTest;

public class ErrorValidations extends BaseTest {
String productName = "ZARA" ;
String country = "India";

	@Test(groups={"error-validations"})
	public void idPasswordTest() throws IOException, InterruptedException {
		landingPage.login("rahulshetty@gmail.com", "WrongPassword");
		Assert.assertEquals(landingPage.getErrorToastMessage(),"Incorrect email or password.");
		
	}
	
	@Test(groups={"error-validations"},retryAnalyzer=RetryTest.class)
	public void verifyInCheckoutPageTest() throws IOException {
		ProductPage productPage = landingPage.login("rahulshetty@gmail.com", "Iamking@000");
		productPage.buyProduct(productName);
		CheckOutPage checkOutPage = productPage.clickOnCartButton();
		Assert.assertTrue(checkOutPage.verifyProduct("ZARA"));// To fail delibirately
	}

}




