package ecommercePractice02.AbstractClass;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import ecommercePractice02.PageObjects.CartPage;
import ecommercePractice02.PageObjects.OrderHistoryPage;

public class Reusables {
	
	WebDriver driver;
	public Reusables(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//button[@routerlink='/dashboard/cart']")
	WebElement cartButtonEle;
	
	@FindBy(xpath="//button[text()=' Sign Out ']")
	WebElement signoutButtonEle;
	
	@FindBy(xpath="//button[@routerlink='/dashboard/myorders']")
	WebElement orderButtonEle;
	
	public void waitForElementToBeVisibleOnPage(WebElement ele) {
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
		w.until(ExpectedConditions.visibilityOf(ele));
	}
	
	public void waitForElementsToBeVisibleOnPage(List<WebElement> ele) {
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
		w.until(ExpectedConditions.visibilityOfAllElements(ele));
	}
	
	public void waitForElementToBeInvisibleOnPage(WebElement ele) {
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
		w.until(ExpectedConditions.invisibilityOf(ele));
	}
	
	public CartPage clickOnCart() {
		cartButtonEle.click();
		CartPage cartPage = new CartPage(driver);
		return cartPage;
	}
	
	public void clickOnSignOut() {
		signoutButtonEle.click();
	}
	
	public OrderHistoryPage clickOnOrderButton() {
		orderButtonEle.click();
		OrderHistoryPage orderHistoryPage = new OrderHistoryPage(driver);
		return orderHistoryPage;
		
	}
	
	
	
	

}
