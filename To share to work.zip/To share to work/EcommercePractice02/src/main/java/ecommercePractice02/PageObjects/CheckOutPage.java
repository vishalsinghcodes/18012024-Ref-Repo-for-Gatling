package ecommercePractice02.PageObjects;
import static org.openqa.selenium.support.locators.RelativeLocator.*;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ecommercePractice02.AbstractClass.Reusables;

public class CheckOutPage extends Reusables{
	WebDriver driver;

	public CheckOutPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div[text()='Name on Card ']/following-sibling::input")
	WebElement nameOnCardTextBoxEle;
	
	@FindBy(xpath="//div[text()='CVV Code ']/following-sibling::input")
	WebElement cvvEle;
	
	@FindBy(xpath="//a[text()='Place Order ']")
	WebElement placeOrderButtonEle;
	
	@FindBy(xpath="//input[@placeholder='Select Country']")
	WebElement countryAutoSuggestTextEle;
	
	@FindBy(xpath="//section[@class='ta-results list-group ng-star-inserted']//span")
	List<WebElement> countrySuggestList; 
	
	public void typeCardName(String nameOnCard) {
		nameOnCardTextBoxEle.sendKeys(nameOnCard);
	}
	
	public void typeCvv(String cvv) {
		cvvEle.sendKeys(cvv);
	}
	
	public ConfirmationPage clickOnPlaceOrderButton() {
		placeOrderButtonEle.click();
		ConfirmationPage confirmationPage = new ConfirmationPage(driver);
		return confirmationPage;
		
	}
	
	public void typeInCountryTextBox(String country) {
		countryAutoSuggestTextEle.sendKeys(country);
	}
	
	public void selectCountry(String actaulcountry) {
		waitForElementsToBeVisibleOnPage(countrySuggestList);
		countrySuggestList.stream().filter(s->s.getText().equalsIgnoreCase(actaulcountry)).collect(Collectors.toList()).get(0).click();
	}
	
	
	
	
	
	
	
	
	
	
	

}
