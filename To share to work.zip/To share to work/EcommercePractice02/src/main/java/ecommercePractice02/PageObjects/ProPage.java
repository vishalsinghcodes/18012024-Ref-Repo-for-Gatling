package ecommercePractice02.PageObjects;

import java.util.List;
import java.util.stream.Collectors;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ecommercePractice02.AbstractClass.Reusables;

public class ProPage extends Reusables{
	WebDriver driver;

	public ProPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//div[@aria-label='Product Added To Cart']")
	WebElement productaddedtoast;
	
	@FindBy(css=".ng-tns-c31-1.ng-star-inserted")
	WebElement spinnerEle;

	By procardsEle = By.xpath("//div[@class='card-body']");

	public void buyPro(String proname) {
		List<WebElement> eles = driver.findElements(procardsEle);
		eles.stream().filter(s -> s.findElement(By.tagName("b")).getText().contains(proname)).map(s -> {
			WebElement el = s.findElement(By.xpath("button[2]"));
			return el;
		}).collect(Collectors.toList()).get(0).click();
		waitForElementToBeVisibleOnPage(productaddedtoast);
		waitForElementToBeInvisibleOnPage(spinnerEle);
	}
	
	public int productCountOnPage() {
		return driver.findElements(By.xpath("//div[@class='card-body']")).size();
	}
	

}
