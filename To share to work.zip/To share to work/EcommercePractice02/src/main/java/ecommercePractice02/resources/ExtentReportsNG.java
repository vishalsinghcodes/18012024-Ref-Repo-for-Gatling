package ecommercePractice02.resources;

import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.ExtentReports;

public class ExtentReportsNG {

	public static ExtentReports getExtentReports() {

		String reportPath = System.getProperty("user.dir") + "\\Reports\\Report.html";
		ExtentSparkReporter reporter = new ExtentSparkReporter(reportPath);
		reporter.config().setDocumentTitle("Test Results");
		reporter.config().setReportName("Test Prac 02");

		ExtentReports extent = new ExtentReports();
		extent.setSystemInfo("Tester", "Vishal Singh");
		extent.attachReporter(reporter);
		return extent;

	}
}
