package ecommercePractice02.Testsuite;

import org.junit.Assert;
import org.testng.annotations.Test;

import ecommercePractice02.BaseTest.BaseTest;
import ecommercePractice02.PageObjects.ProPage;

public class ErrorValidations extends BaseTest{
	
	@Test(groups="error-validation")
	public void validateincorrectlogintoast() {
		landingPage.loginApplication("abc@gmai.com", "AnyPassword");
		landingPage.validateLoginErrorToast();
	}
	
	@Test
	public void checkProductCount() {
		ProPage propage = landingPage.loginApplication("Udemyselenium@gmail.com", "Password1234");
		Assert.assertEquals(propage.productCountOnPage(),4);
	}
	
	
	

}
