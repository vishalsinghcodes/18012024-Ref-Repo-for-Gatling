package ecommercePractice02.Testsuite;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.junit.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ecommercePractice02.BaseTest.BaseTest;
import ecommercePractice02.BaseTest.RetryClass;
import ecommercePractice02.PageObjects.CartPage;
import ecommercePractice02.PageObjects.CheckOutPage;
import ecommercePractice02.PageObjects.ConfirmationPage;
import ecommercePractice02.PageObjects.OrderHistoryPage;
import ecommercePractice02.PageObjects.ProPage;

public class Test01 extends BaseTest {

	@Test(groups = "error-validation",dataProvider = "getdata",retryAnalyzer = RetryClass.class)
	public void PlaceOrder(HashMap<String,String> data) throws IOException {
		ProPage propage = landingPage.loginApplication(data.get("un"), data.get("pw"));
		propage.buyPro("IPHONE");
		CartPage cartPage = propage.clickOnCart();
		Assert.assertTrue(cartPage.checkProInCart("IPHONE"));
		CheckOutPage checkoutPage = cartPage.clickOnCheckOutButton();
		checkoutPage.typeCvv("123");
		checkoutPage.typeCardName("Vishal Singh");
		checkoutPage.typeInCountryTextBox("Ind");
		checkoutPage.selectCountry("India");
		ConfirmationPage confirmationPage = checkoutPage.clickOnPlaceOrderButton();
		confirmationPage.getOrderNumbers().stream().forEach(s -> System.out.println(s));
		confirmationPage.clickOnSignOut();

	}

	@Test(dependsOnMethods = "PlaceOrder", groups = "error-validation")
	public void checkOrderHistory() {
		ProPage propage = landingPage.loginApplication("Udemyselenium@gmail.com", "Password1234");
		OrderHistoryPage orderHistoryPage = propage.clickOnOrderButton();
		Assert.assertTrue(orderHistoryPage.checkOrderHistoryFor("IPHONE"));
		orderHistoryPage.clickOnSignOut();

	}
	
	@DataProvider
	public Object[][] getdata() throws IOException{
		List<HashMap<String,String>> data = getdatafromjson(System.getProperty("user.dir")+"\\src\\test\\java\\ecommercePractice02\\TestData\\dataProvider.Json");
		return new Object[][] {{data.get(0)},{data.get(1)}};
	}


}
