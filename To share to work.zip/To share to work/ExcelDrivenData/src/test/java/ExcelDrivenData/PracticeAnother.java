package ExcelDrivenData;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class PracticeAnother {
	

	@Test
	public void fetchExcelData() throws IOException {
		List<String> list = new ArrayList<String>();
		List<String> listFromPage = Arrays.asList(new String[] {"Greetings","Singh", "How", "AllGood"});	
		DataFormatter formatter = new DataFormatter();
		String pathToFile = System.getProperty("user.dir") + "\\For Data Deriving Test NG.xlsx";
		FileInputStream fis = new FileInputStream(pathToFile);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		int noOfSheets = workbook.getNumberOfSheets();
		XSSFSheet reqSheet = null;
		for (int i = 0; i < noOfSheets; i++) {
			if(workbook.getSheetName(i).equalsIgnoreCase("Sheet1"))
				reqSheet = workbook.getSheetAt(i);
		}
		XSSFRow firstRow = reqSheet.getRow(0);
		int numberOfRows = reqSheet.getPhysicalNumberOfRows();
		int numberOfCols = firstRow.getLastCellNum();
		
		int cellat = 0;
		int numberOfCells = firstRow.getPhysicalNumberOfCells();
		for(int i =0;i<numberOfCells;i++) {
			if(firstRow.getCell(i).getStringCellValue().equalsIgnoreCase("Communication")) {
				cellat=i;
				break;
			}
		}
		
		
		for(int i =1;i<numberOfRows;i++) {
			XSSFRow temp = reqSheet.getRow(i);
			String value = temp.getCell(cellat).getStringCellValue();
			list.add(value);
		}
	
		System.out.println(list.stream().collect(Collectors.toSet()).equals(listFromPage.stream().collect(Collectors.toSet())));
		
	}


}
