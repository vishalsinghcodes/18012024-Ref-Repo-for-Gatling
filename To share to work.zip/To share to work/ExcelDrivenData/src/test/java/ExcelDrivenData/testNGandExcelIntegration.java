package ExcelDrivenData;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.WorksheetDocument;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class testNGandExcelIntegration {
	@Test(dataProvider = "getdata")
	public void testcasedata(String a, String b, String c) {
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);

	}

	@DataProvider
	public Object[][] getdata() throws IOException {
		DataFormatter formatter = new DataFormatter();
		// Object data[][] =
		// {{"Hello","Text",1},{"Hello2","Text2",2},{"Hello3","Text3",3}};
		FileInputStream fis = new FileInputStream("D:\\Excel Data Driven Practice\\For Data Deriving Test NG.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		int noOfSheets = workbook.getNumberOfSheets();
		XSSFSheet reqSheet = null;
		for (int i = 0; i < noOfSheets; i++) {
			if (workbook.getSheetName(i).equalsIgnoreCase("Sheet1"))
				reqSheet = workbook.getSheetAt(i);
		}
		int noOfRows = reqSheet.getPhysicalNumberOfRows();
		// Iterator<Row> rowit = reqSheet.rowIterator();
		XSSFRow row = reqSheet.getRow(0);
		int noOfColumns = row.getLastCellNum();
		Object data[][] = new Object[noOfRows - 1][noOfColumns];
		// Now to store in multi dim array
		for (int i = 0; i < noOfRows - 1; i++) {
			row = reqSheet.getRow(i + 1);
			for (int j = 0; j < noOfColumns; j++) {
				XSSFCell cell = row.getCell(j);
				//formatter.formatCellValue(cell);
				data[i][j] = formatter.formatCellValue(cell);
				
			}
		}

		return data;
	}

	@Test  // This is rough and is just used to test the values by sysout from excel
	public void roughWork() throws IOException {
		FileInputStream fis = new FileInputStream("D:\\Excel Data Driven Practice\\For Data Deriving Test NG.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		int noOfSheets = workbook.getNumberOfSheets();
		XSSFSheet reqSheet = null;
		for (int i = 0; i < noOfSheets; i++) {
			if (workbook.getSheetName(i).equalsIgnoreCase("Sheet1"))
				;
			reqSheet = workbook.getSheetAt(i);
		}
		int noOfRows = reqSheet.getPhysicalNumberOfRows();
		// Iterator<Row> rowit = reqSheet.rowIterator();
		XSSFRow row = reqSheet.getRow(0);
		int noOfColumns = row.getLastCellNum();
		Object data[][] = new Object[noOfRows - 1][noOfColumns];
		// Now to store in multi dim array
		for (int i = 0; i < noOfRows - 1; i++) {
			row = reqSheet.getRow(i + 1);
			System.out.println("This is row no : "+i);
			for (int j = 0; j < noOfColumns; j++) {
				// data[i][j] = row.getCell(j).getStringCellValue();
				System.out.println(row.getCell(j));
			}
		}
	}

}
