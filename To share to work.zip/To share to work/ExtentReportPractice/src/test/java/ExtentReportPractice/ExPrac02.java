package ExtentReportPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ExPrac02 {
	ExtentReports extent;

	@BeforeTest
	public void Test0101() {
		String repopath = System.getProperty("user.dir") + "\\reporttest123\\report.html";
		ExtentSparkReporter reporter = new ExtentSparkReporter(repopath);
		reporter.config().setReportName("Automation test");
		reporter.config().setDocumentTitle("Test Results");

		extent = new ExtentReports();
		extent.setSystemInfo("Tester", "Vishal Singh");
		extent.attachReporter(reporter);
	}

	@Test
	public void Test0202() {
		ExtentTest test = extent.createTest("Test 0202");
		WebDriverManager.chromedriver().config();
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.google.com");
		driver.close();
		test.pass("It is Passed");
		
	}

	@Test
	public void Test0303() {
		ExtentTest test = extent.createTest("Test 0303");
		WebDriverManager.chromedriver().config();
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.google.com");
		driver.close();
		test.pass("It is Passed");
		
	}
	@AfterTest
	public void afterTest() {
		extent.flush();
	}

}
