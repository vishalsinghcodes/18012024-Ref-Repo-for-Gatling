package ExtentReportPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Practice {
	ExtentReports extent;
	@BeforeTest
	public void reportcreator() {
		String path = System.getProperty("user.dir")+"\\reportTestFolder\\report.html";
		ExtentSparkReporter reporter = new ExtentSparkReporter(path);
		reporter.config().setDocumentTitle("Test Reults");
		reporter.config().setReportName("Automation test");
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		extent.setSystemInfo("Tester", "Vishal Singh");
	}
	
	@Test
	public void test01() {
		ExtentTest test = extent.createTest("Test 01");
		WebDriver driver = new ChromeDriver();
		WebDriverManager.chromedriver().config();
		driver.get("http://www.google.com");
		test.pass("It passed");
		extent.flush();
			
	}
	
	@Test
	public void Test02() {
		ExtentTest test = extent.createTest("Test 02");
		WebDriver driver = new ChromeDriver();
		WebDriverManager.chromedriver().config();
		driver.get("http://www.google.com");
		test.fail("Test failed");
		extent.flush();
	}
	
	

}
