
public class FirstProgram {

	public static void main() {
		System.out.println("Hello");
	}
}
