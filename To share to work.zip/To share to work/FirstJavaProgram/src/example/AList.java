package example;


import java.util.*;
public class AList {

	public static void main(String args[]) {

		ArrayList<String> arr2 = new ArrayList<String>();
		arr2.add("Vishal");
		arr2.add("Vivek");
		arr2.add("Singh");
		arr2.add("Practice");
		arr2.add("Selenium");
		
		System.out.println(arr2.get(4));
		
		for(String a:arr2) {
			System.out.println(a);
		}
		
		boolean cont = arr2.contains("Selenium")?true:false;
		System.out.println(cont);
		
		String simplearr[] = {"India", "America", "China", "Russia", "England"};
		List<String> conlist = Arrays.asList(simplearr);
		System.out.println(conlist.contains("India"));
	}

}
