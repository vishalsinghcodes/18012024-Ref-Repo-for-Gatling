package example;

public class FirstPog {

	public static void main(String arg[]) {
		System.out.println("Hello");
		boolean a = false;
		System.out.println(a);
		char b = '\u1111';
		System.out.println(b);
		int first = 2; 
		int sec = 3; 
		int third = 4; 
		int res = first<sec?4:6;
		System.out.println(res);
		
	}
}
