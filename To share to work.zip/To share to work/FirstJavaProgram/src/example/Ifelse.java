package example;
import java.lang.String;
public class Ifelse {
	public static void main (String args[]) {
		
//		int a = 2 ; 
//		int b = 10; 
//		int c = 2; 
//		int res = 0;
//		if(a>b&&a>c) 
//			res = a;
//		else if(b>c)
//			res = b;
//		else 
//			res = c;
		
		
	}

}
