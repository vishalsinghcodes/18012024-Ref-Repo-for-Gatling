package example;



class animal {
	animal(){
		System.out.println("This is constructor of parent class");
		System.out.println("This is constructor of parent class");
	}
	String str = "parent";
	public void eat() {
		System.out.println("Animal is eating");
	}
}

class dog extends animal {
	
	{System.out.println("This is in instance ini block");}
	dog(){
		super();
	}
	public void dogeat() {
		System.out.println("Dog is eating");
		System.out.println(super.str);
		super.eat();
		
	}
}

//class cat extends animal {
//	public void cateat() {
//		System.out.println("cat is eating");
//	}
//}

public class Inheritance {

	public static void main(String args[]) {
		dog d = new dog();
		d.eat();
		d.dogeat();
		

	}

}