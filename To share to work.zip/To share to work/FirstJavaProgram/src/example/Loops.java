package example;

public class Loops {

	public static void main(String args[]) {
		
		String [] str = {"vishal", "Vivek", "Ok"};
		
		for(String s:str) {
			System.out.println(s);
		}
	
	for(int i=0;i<10;i++) {
		System.out.println("Vishal Singh");
	}
	
	int i =0 ; 
	while(i<10) {
		if(i%2==0)
		System.out.println(i);
		i++;
	}
	
	}

}
