package example;

import java.util.Scanner;

public class Rough {
	
	public static void main(String arg[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please Enter a number");
		System.out.println();
		int a = sc.nextInt();
		System.out.println();
		boolean b = a%2==0?true:false;
		String s = b==true?"and it is an even number":"It is an odd number";
		System.out.println("You have entered : "+ a +" "+ s);
	}

}
