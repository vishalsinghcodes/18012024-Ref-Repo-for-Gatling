package example;

public class RoughTwo {
	
	public static void main(String args[]) {
		
		int arr[] = {1,3,4,4,5,6,7,8,9};
		int v[] = new int[5];
		
//		for (int i=0;i<arr.length;i++) {
//			System.out.println(arr[i]);
//		}
		
//		for(int a:arr) {
//			System.out.println(a);
//		}
		
		String strarr[] = {"Delhi", "Lucknow", "Ghaziabad", "Punjab"};
//		for (int i=0;i<strarr.length;i++) {
//			System.out.println(strarr[i]);
//		}
		
	for(String d :strarr) {
		System.out.println(d);
	}
		
	}

}
