package example;

public class Stringex {

	public static void main(String args[]) {
		
		String s1 = "Vishal";
		String s2 = "Vishal";
		String s3 = new String();
		s3 = "My name is Vishal Singh";
		System.out.println(s3);
		
		String str[] = s3.split(" ");// splitted on basis of space
		for(String a:str) {
			System.out.println(a);
		}
		
		String str2[] = s3.split("name");
		for(String a:str2) {
			System.out.println(a);
		}
		// trimming space 
		System.out.println(str2[1].trim());
		
		for(int i =0;i<s3.length();i++) {
			System.out.println(s3.charAt(i));
		}
		
		//reverse
		for(int i =s3.length()-1;i>=0;i--) {
			System.out.print(s3.charAt(i));
		}
		
	}
	
}
