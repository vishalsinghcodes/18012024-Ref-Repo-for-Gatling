import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class EcommerceGreenKart {

	public static void main(String args[]) {
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().window().maximize();
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
		// //button[contains(text(),'ADD TO CART')]
		List<WebElement> prolist = new ArrayList<WebElement>();
		prolist = driver.findElements(By.cssSelector("h4.product-name"));
		int procount = 0;
		for (WebElement a : prolist) {
			System.out.println(a.getText());
			procount++;
			if (a.getText().contains("Cucumber")) {
				System.out.println("Cucumber present at " + procount);
				break;
			}
		}
		driver.findElement(By.xpath("(//a[@class='increment'])["+procount+"]")).click();
		driver.findElement(By.xpath("(//a[@class='increment'])["+procount+"]")).click();
		driver.findElement(By.xpath("(//button[contains(text(),'ADD TO CART')])["+procount+"]")).click();
		

		driver.close();

	}

}
