import java.util.Scanner;

public class Methods {

static	public String getwebsite() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the website you want to visit");
		String website = sc.next();
		return website;
	}
}
