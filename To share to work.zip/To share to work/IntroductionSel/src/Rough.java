import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Rough {
	
	public static void main(String args[]) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://rahulshettyacademy.com/dropdownsPractise/");
		driver.manage().window().maximize();
		WebElement ele = driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency"));
		Select condrp = new Select(ele);
		Thread.sleep(2000);
		condrp.selectByIndex(2);
		System.out.println(condrp.getFirstSelectedOption().getText());
		Thread.sleep(2000);
		condrp.selectByValue("USD");
		System.out.println(condrp.getFirstSelectedOption().getText());
		Thread.sleep(2000);
		condrp.selectByVisibleText("AED");
		System.out.println(condrp.getFirstSelectedOption().getText());
		Thread.sleep(1000);
		driver.close();
		
	}

}
