import java.time.Duration;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class SelectorPrac {

	public static void main(String args[]) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","D:\\New Volume\\Udemy Selenium\\Practice 2023\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("http://rahulshettyacademy.com/locatorspractice/");
		driver.findElement(By.id("inputUsername")).sendKeys("VishalSingh");
		driver.findElement(By.name("inputPassword")).sendKeys("password");
		driver.findElement(By.className("signInBtn")).click();	
		String err = driver.findElement(By.cssSelector("p.error")).getText();
		System.out.println(err);
		driver.findElement(By.linkText("Forgot your password?")).click();
	
		
		driver.findElement(By.xpath("//input[@placeholder='Name']")).sendKeys("Manish");
		driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys("yoyo@gmail.com");
		driver.findElement(By.xpath("//input[@placeholder='Email']")).clear();
		driver.findElement(By.xpath("//input[@type='text'][2]")).sendKeys("yoyo123@gmail.com");
		//driver.findElement(By.cssSelector("input[placeholder='Phone Number']")).sendKeys("1245678973");
		driver.findElement(By.xpath("//form/input[3]")).sendKeys("1245678973");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("button.reset-pwd-btn")).click();
		String passtext = driver.findElement(By.cssSelector(".infoMsg")).getText();
		//System.out.println(driver.findElement(By.cssSelector(".infoMsg")).getText());
		System.out.println(passtext);
		String password = passtext.split("'")[1];
		System.out.println(password);
		driver.findElement(By.cssSelector("button.go-to-login-btn")).click();
		driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys("Vishal");
		driver.findElement(By.name("inputPassword")).sendKeys(password);
		Thread.sleep(2000);
		driver.findElement(By.id("chkboxOne")).click();
		driver.findElement(By.name("chkboxTwo")).click();
		driver.findElement(By.cssSelector("button[class*='submit']")).click();
		Thread.sleep(2000);
		String texttotest = driver.findElement(By.tagName("p")).getText();
		Assert.assertEquals(texttotest, "You are successfully logged in.");
		String name = driver.findElement(By.tagName("h2")).getText().split(" ")[1].split(",")[0];
		System.out.println(name);
		Assert.assertEquals(name, "Vishal");
		System.out.println("Both the test passed");
		System.out.println("Now logging out");
		driver.findElement(By.xpath("//button[contains(text(),'Log Out')]")).click();
		driver.close();
		
		
		
		
		
		
		
	

	}

}
