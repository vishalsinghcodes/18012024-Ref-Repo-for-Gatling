import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Selintro {

	public static void main(String[] args) {
		// WebDriver driver = new WebDriver();

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice");
		System.out.println("Type E for Edge");
		System.out.println("Type C for Chrome");
		System.out.println("Type M for Mozilla Firefox");
		String choice = sc.nextLine();
		System.out.println(choice);

		switch (choice) {
		case "E": {
			System.out.println("Your code will run in Edge browser");
			System.setProperty("webdriver.edge.driver","D:\\New Volume\\Udemy Selenium\\Practice 2023\\msedgedriver.exe");
			WebDriver driver = new EdgeDriver();
			script(driver);
			break;
		}
		case "M": {
			System.out.println("Your code will run in Firefox browser");
			System.setProperty("webriver.gecko.driver","D:\\New Volume\\Udemy Selenium\\Practice 2023\\geckodriver.exe");
			WebDriver driver = new FirefoxDriver();
			script(driver);
			break;
		}
		case "C": {
			System.out.println("Your code will run in Chrome browser");
			System.setProperty("webdriver.chrome.driver",
					"D:\\New Volume\\Udemy Selenium\\Practice 2023\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			script(driver);
			break;

		}
		default: {
			System.out.println("Wrong choice, Please try again");
			break;

		}

		}

	}

	static void script(WebDriver driver) {
		driver.get("http://www.google.com");
		driver.manage().window().fullscreen();
		String address = driver.getCurrentUrl();
		System.out.println(address);
		System.out.println(driver.getTitle());
		System.out.println();
		driver.navigate().to("http://www.yahoo.com");

		System.out.println(driver.getTitle());
		driver.navigate().back();

		System.out.println(driver.getTitle());
		driver.navigate().forward();

		System.out.println(driver.getTitle());
		driver.close();

	}

}
