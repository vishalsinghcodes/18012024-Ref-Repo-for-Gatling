import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class SiblingParenttraverselocator {

	public static void main(String[] args) {
		//System.setProperty("webdriver.edge.driver","D:\\New Volume\\Udemy Selenium\\Practice 2023\\msedgedriver.exe");
		WebDriver driver = new EdgeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		driver.manage().window().maximize();
		
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		driver.navigate().to("http://www.google.com");
		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().back();
		System.out.println(driver.findElement(By.xpath("//header/div/button[1]/following-sibling::button[1]")).getText());// traversing to child 
		driver.findElement(By.xpath("//header/div/button[1]/following-sibling::button[1]")).click();
		// paret //header/div/button[1]/parent::div
		driver.findElement(By.xpath("//header/div/button[1]/parent::div/button[2]")).click(); // traversing to parent and going to child
		driver.close();

	}

}
