package prac01;

import org.testng.annotations.Test;

public class Prac0101 extends Prac0102 {

	@Test
	public void test01() {
		int a =3;
		Prac0103 ob = new Prac0103(a);
		//Prac0104 ob1 = new Prac0104(a);
		//methodOfClass02();
		System.out.println(ob.increment());
		System.out.println(ob.decrement());
		System.out.println(ob.multiplyby10());
		System.out.println(ob.multiplyby5());
	}

}
