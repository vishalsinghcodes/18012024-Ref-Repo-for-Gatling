package prac01;

import org.testng.annotations.AfterTest;

public class Prac0102 {
	
	public static void methodOfClass02() {
		System.out.println("methodOfClass02");
	}
	
	@AfterTest
	public void afterafter() {
		System.out.println("afterafter");
	}

}
