package prac01;

public class Prac0103 extends Prac0104{
	int a;

	public Prac0103(int a) {
		super(a);
		this.a = a;
	}

	// int a ;
	public int increment() {
		a = a + 1;
		return a;
	}
	
	public int decrement() {
		a--;
		return a;
	}
	
	

}
