package prac01;

public class Prac0104 {

	
	int a;
	public Prac0104(int a) {
		this.a = a;
	}

	public int multiplyby10() {
		a=a*10;
		return a;
	}
	
	public int multiplyby5() {
		a=a*5;
		return a;
	}
	
}
