package packageA;
import java.text.DateFormat;  
import java.text.SimpleDateFormat;  
import java.util.Date;  
import java.util.Calendar;  

import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Addtwono {
	public static void main(String args[]) {
		
		Date date = Calendar.getInstance().getTime();  
        DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
        String strDate = dateFormat.format(date); 
        System.out.println(strDate);
		
	}

}
