package packageA;

class test1 {
	
	int a = 5;
	String name = "Vishal Singh";
	
}

class test2{
	int a = 7;
	String name = "abc xyz";
	
}
	// Java File must be named with class name containing the Main() method.
class ClassPractice07{
	
	public static void main(String args[]) {
 
		test1 abc = new test1();
		System.out.println(abc.a);
		System.out.println(abc.name);
		
		test2 m = new test2();
		System.out.println(m.a);
		System.out.println(m.name);
		
}
}