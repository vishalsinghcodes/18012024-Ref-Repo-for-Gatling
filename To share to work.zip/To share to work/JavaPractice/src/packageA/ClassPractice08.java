package packageA;

// Ways of initializing the object 
//1. using reference variable

class Student {
	int id; 
	String name;
	
	void iniclass(int a, String str) {
		this.id = a;
		this.name = str;
	}
	
}


public class ClassPractice08 {

	public static void main(String[] args) {
		//1. Using reference variable
		Student a = new Student();
		a.id = 10;
		a.name = "Vishal";
		Student b = new Student();
		b.id = 20;
		b.name = "Vivek";
		System.out.println(a.name);
		System.out.println(b.name);
		
		//2. Using method
		Student c = new Student();
		c.iniclass(56, "Sumit");
		System.out.println(c.id);
		System.out.println(c.name);
	}

}
