package packageA;

public class Controlflow06 {

	public static void main(String[] args) {
		int a = 8 ;
		int b = 7;
		
		/*  if else statements 
		if(a<b) {
			System.out.print("Yes, a is lesser than b");
		}else {
			System.out.print("No, A is not less than B");
		}
		*/

	}

}
