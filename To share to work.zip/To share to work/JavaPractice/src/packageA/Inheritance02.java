package packageA;
// Multilevel Inheritance
class Animals{
	void eat() {
		System.out.println("eating");
	}
}
class Dogs extends Animals {
	void bark() {
		System.out.println("Barking");
	}
}

class BabyDog extends Dogs {
	void weep() {
		System.out.println("weeping");
	}
}

public class Inheritance02 {

	public static void main(String[] args) {
		BabyDog bd = new BabyDog();
		bd.eat();
		bd.bark();
		bd.weep();

	}

}
