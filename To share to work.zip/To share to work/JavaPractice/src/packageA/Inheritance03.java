package packageA;
// Heirarchical inheritance
class Animalss{
	void eat() {
		System.out.println("eating");
	}
}
class Dogss extends Animalss {
	void bark() {
		System.out.println("Barking");
	}
}

class Cat extends Animalss {
	void meow() {
		System.out.println("meow");
	}
}

public class Inheritance03 {


	public static void main(String[] args) {
		Cat c = new Cat();
		Dog d = new Dog();
		c.eat();
		d.eat();
		d.bark();
		c.meow();
		

	}

}
