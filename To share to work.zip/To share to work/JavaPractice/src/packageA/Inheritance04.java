package packageA;
// Aggregation 

class Operation {
	int square(int a) {
		return a * a;
	}
}

class circle {
	Operation op = new Operation(); // having object of one class in another
	double pi = 3.14;
	double area(int radius) {
		return pi * op.square(radius);
	}

}

public class Inheritance04 {
	public static void main(String[] args) {
		circle c1 = new circle();
		System.out.print(c1.area(15));

	}

}
