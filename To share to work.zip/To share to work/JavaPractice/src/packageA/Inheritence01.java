package packageA;


class Animal{
	void eat() {
		System.out.println("eating");
	}
}
class Dog extends Animal {
	void bark() {
		System.out.println("Barking");
	}
}


public class Inheritence01 {

	public static void main(String[] args) {
		Dog d = new Dog();
		d.eat();
		d.bark();

	}

}
