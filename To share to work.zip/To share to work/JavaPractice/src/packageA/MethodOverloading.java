package packageA;

import java.util.Scanner;

public class MethodOverloading {

	static int add(int a, int b, int c) {
		int add = a + b + c;
		return add;
	}

	static int add(int a, int b) {
		int add = a + b;
		return add;
	}
	
	static void display(int a) {
		System.out.println("You have entered an integer : "+ a);
	}
	
	static void display(String str) {
		System.out.println("You have entered an String : "+ str);
	}

	public static void main(String[] args) {

		Scanner scn = new Scanner(System.in);
		int a = scn.nextInt();
		int b = scn.nextInt();
		int c = scn.nextInt();

		System.out.println("How many numbers you wanna add 2 or 3 ");
		int choice = scn.nextInt();

		switch (choice) {
		case 2:
			System.out.println(add(a, b));
			break;
		case 3:
			System.out.println(add(a, b, c));
			break;
		default:
			System.out.print("Wrong choice");
		}
		//System.out.println("Enter an inteer or a string");
		//scn.next();
		//display(1);
		display("Vishal");

	}

}
