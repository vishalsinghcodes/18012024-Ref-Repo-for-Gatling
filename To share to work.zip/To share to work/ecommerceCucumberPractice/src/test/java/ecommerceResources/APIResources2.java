package ecommerceResources;

public enum APIResources2 {

	Login("/auth/login"), createProduct("/product/add-product"),
	GetAllPros("/product/get-all-products"),DeleteProduct("/product/delete-product/"), CreateOrder("/order/create-order");

	private String resource;

	APIResources2(String resource) {
		this.resource = resource;
	}

	public String getResource() {
		return resource;
	}

}
