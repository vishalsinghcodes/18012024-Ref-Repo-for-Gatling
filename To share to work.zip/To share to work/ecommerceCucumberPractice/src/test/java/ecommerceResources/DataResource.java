package ecommerceResources;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import pojoClassesForEcommerce.CreateOrderRequestPOJO;
import pojoClassesForEcommerce.CredentialsRequestPOJO;
import pojoClassesForEcommerce.Orders;

public class DataResource {
	
	@Test
	public String returncredsJsonFile() throws IOException {
		String pathToJson = System.getProperty("user.dir")+"\\src\\test\\java\\ecommerceResources\\logincreds.json";
		String jsonasString =  new String(Files.readAllBytes(Paths.get(pathToJson)));
		return jsonasString;	
	}
	
	public CredentialsRequestPOJO credsRequestBody(String username , String password) {
		CredentialsRequestPOJO credsbody = new CredentialsRequestPOJO();
		credsbody.setUserEmail(username);
		credsbody.setUserPassword(password);	
		return credsbody;
	}
	
	public CreateOrderRequestPOJO createProductRequestBody(String Country , String proID) {
		Orders order = new Orders();
		order.setCountry(Country);
		order.setProductOrderedId(proID);
		List<Orders> ordersAsList = new ArrayList<Orders>();
		ordersAsList.add(order);
		CreateOrderRequestPOJO crePojo = new CreateOrderRequestPOJO();
		crePojo.setOrders(ordersAsList);	
		
		return crePojo;
		
	}
	
	
	

}
