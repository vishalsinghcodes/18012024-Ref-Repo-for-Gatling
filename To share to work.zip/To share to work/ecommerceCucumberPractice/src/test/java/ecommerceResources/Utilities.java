package ecommerceResources;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Properties;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Utilities {
	static RequestSpecification reqspec;

	public RequestSpecification Baserequest() throws IOException {

		if (reqspec == null) {

			PrintStream log = new PrintStream(new FileOutputStream("log.txt"));

			reqspec = new RequestSpecBuilder().setBaseUri(getvalueFromGlobeProps("baseurl"))
					.addFilter(RequestLoggingFilter.logRequestTo(log))
					.addFilter(ResponseLoggingFilter.logResponseTo(log)).build();
			return reqspec;
		}
		return reqspec;
	}

	public String getvalueFromGlobeProps(String key) throws IOException {
		String pathToFile = System.getProperty("user.dir")
				+ "\\src\\test\\java\\ecommerceResources\\GlobeProp.properties";
		FileInputStream fis = new FileInputStream(pathToFile);
		Properties prop = new Properties();
		prop.load(fis);
		return prop.getProperty(key);

	}

	public Object fetchValuefromResponse(Response response, String key) {
		JsonPath jp = new JsonPath(response.asString());
		return jp.get(key);

	}

}
