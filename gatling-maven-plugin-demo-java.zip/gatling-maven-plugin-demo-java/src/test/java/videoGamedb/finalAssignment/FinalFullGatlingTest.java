package videoGamedb.finalAssignment;

import io.gatling.javaapi.core.*;
import io.gatling.javaapi.http.*;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.*;
public class FinalFullGatlingTest extends Simulation{

    //HTTP Protocol
    //RUNTIME PARAMETERS
    //FEEDERS
    //BEFORE BLOCK
    //HTTP CALLS
    // Scenario -
    //1. Get all video games
    //2. Create new game
    //3. Get details of newly created game
    //4. delete the newly created game
    // Load simulation
    //After block - To print test is completed



}
